# GitHub Pages Upload

Upload everything in this `site-previews` folder, not just the `index.html` files.

Required files and folders:

- `index.html`
- `.nojekyll`
- `assets/site.css`
- every business folder, for example `bnc-landscaping/index.html`

If your GitHub Pages site is:

```text
https://YOUR-USERNAME.github.io/YOUR-REPO/
```

Then the preview links should look like:

```text
https://YOUR-USERNAME.github.io/YOUR-REPO/bnc-landscaping/
https://YOUR-USERNAME.github.io/YOUR-REPO/bright-beginnings-academy/
```

After GitHub Pages is live, put that base URL in `data/outreach-settings.json` as `previewBaseUrl`, then regenerate the emails:

```powershell
node scripts/generate-outreach.mjs
```

Do not send the email drafts until you add a valid physical mailing address, registered PO box, or registered private mailbox.
